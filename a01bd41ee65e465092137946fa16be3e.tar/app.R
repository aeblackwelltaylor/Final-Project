#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(jsonlite)
library(tidyverse)
library(lubridate)
library(shiny)

# Find out different aspects of different NHL Teams
ui <- fluidPage(
   
   # Application title
   titlePanel("NHL Team"),
   
   # Sidebar with a slider input for number of bins 
   sidebarLayout(
      sidebarPanel(
         textInput(inputId ="n",
                   "Number of Teams", value = 31
                     
                     
                     
                    )
      ),
      
      # Show a plot of the generated distribution
      mainPanel(
         tableOutput('table')
      )
   )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
   
   output$table <- renderTable({
      # generate bins based on input$bins from ui.R
      
     hockey=fromJSON("https://statsapi.web.nhl.com/api/v1/teams")
      
      # determine the name of NHL Teams and Locations
      hockey$teams %>%
        select(id, name, locationName)
      
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

